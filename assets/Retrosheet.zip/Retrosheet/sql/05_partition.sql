USE `retrosheet`;

UPDATE games_bck
SET YEAR_ID = SUBSTR(GAME_ID,4,4);

UPDATE events_bck
SET YEAR_ID = SUBSTR(GAME_ID,4,4);

INSERT INTO games
SELECT * from games_bck;

INSERT INTO events
SELECT * from events_bck;

CREATE INDEX YEAR_IDX on events (YEAR_ID);

CREATE INDEX YEAR_IDX on games (YEAR_ID);